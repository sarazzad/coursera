# primer_android
Primer proyecto android del curso fundamentos de android
* Realizado en android studio 4.0.2
* Soporte los siguientes idiomas
a. Español
b. Inglés
c. Francés
d. Alemán
* Usa fondo de tipo nine-patch
* Brinda soporte a múltiples pantallas de modo que la interfaz de usuario debe verse correctamente distribuida sin importar el tamaño y orientación de pantalla donde se este visualizando.

